Arduino Example Servomotor 360 degrees
============
Sample code to control a servo motor 360 degrees.

Copyright 2015 by Diego de los Reyes http://diegorys.es

For use this library, you must connect a servo motor 360 degrees
to your Arduino Board.

More info:

http://fritzing.org/projects/servo-motor-360-degrees